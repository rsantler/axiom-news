# AXIOM News Vietnam — Next.js 14 App

AI-assisted, fact-first newsroom for Vietnam coverage.

## Stack

- **Next.js 14** (App Router, server components + ISR)
- **Supabase** (Postgres, single source of truth)
- **TypeScript** throughout

---

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Configure Supabase

Copy `.env.example` to `.env.local` and fill in your credentials:

```bash
cp .env.example .env.local
```

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Run the Supabase schema

The schema file is bundled in the project root: `schema_supabase.sql`

In your Supabase SQL editor, paste and run the contents to create all tables and indexes.

### 4. Dev server

```bash
npm run dev
```

Visit `http://localhost:3000`

---

## Type Safety

The app is fully typed end-to-end against the schema:

- `lib/database.types.ts` — hand-authored Database interface matching `schema_supabase.sql` exactly
- `lib/supabase.ts` — typed `SupabaseClient<Database>` for both browser and server
- `types/index.ts` — re-exports row types as `FactCard`, `Explainer`, `EventCluster`, etc.

To regenerate types from a live Supabase project:
```bash
npx supabase gen types typescript --project-id <your-project-id> > lib/database.types.ts
```

---



| Route | Description |
|-------|-------------|
| `/` | Homepage — Breaking, Explainers, Live Wire, Global→VN, Digest previews |
| `/live` | Live Wire feed with filters (region, confidence, language) |
| `/explains` | Explainers with video embeds and confidence scores |
| `/story/[cluster_id]` | Canonical story page with full timeline, explainer, corrections |
| `/digest/daily` | Daily Wrap archive |
| `/digest/weekly` | Weekly Outlook archive |
| `/methodology` | Source tiers, confidence labels, versioning policy |
| `/corrections` | Public corrections log |
| `/about` | AI disclosure, scope, non-endorsement statement |

---

## API Routes

| Route | Description |
|-------|-------------|
| `GET /api/facts` | Fact cards. Params: `lang`, `limit`, `confidence`, `region` |
| `GET /api/explainers` | Explainers. Params: `lang`, `limit` |
| `GET /api/story?id=<cluster_id>` | Full story: cluster + facts + explainer + corrections |
| `GET /api/digest?kind=daily|weekly` | Digests. Params: `lang`, `limit` |

---

## Design System

The UI uses an editorial newsroom aesthetic:

- **Fonts**: Playfair Display (headings) + IBM Plex Sans (body) + IBM Plex Mono (labels/meta)
- **Colors**: Ink on paper. Accent red for breaking/corrections. Navy wire for explainers.
- **Confidence badges**: Green (HIGH), Amber (MED), Orange (DEV)
- **No political styling** — purely factual, neutral palette

---

## Publishing Rules (enforced in UI)

- Breaking banner: only when `is_breaking = true` AND `confidence_level = HIGH`
- Confidence label always shown on every item
- Version ID always displayed in muted text
- No homepage confidence meter (per spec)
- VI language falls back to EN with a note if not available

---

## Revalidation (ISR)

| Page | Revalidate |
|------|-----------|
| Homepage | 60s |
| Live Wire | Client-side (SWR pattern) |
| Explainers | 120s |
| Story pages | 60s |
| Digests | 300–600s |
| Corrections | 300s |
