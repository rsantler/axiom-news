import { createClient, SupabaseClient } from '@supabase/supabase-js'
import type { Database } from './database.types'

// ── Typed Supabase client ──────────────────────────────────────────────────
// All queries are fully typed against the confirmed schema (schema_supabase.sql v1).

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Browser singleton (for Client Components)
export const supabase: SupabaseClient<Database> = createClient<Database>(
  supabaseUrl,
  supabaseKey
)

// Per-request server client (for Server Components & Route Handlers).
// Returns a fresh instance each call to avoid cross-request caching.
export function createServerClient(): SupabaseClient<Database> {
  return createClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      auth: { persistSession: false }, // server — no session storage
    }
  )
}
