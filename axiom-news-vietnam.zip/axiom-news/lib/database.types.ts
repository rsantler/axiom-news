// Auto-typed from schema_supabase.sql (AXIOM News Vietnam v1)
// Regenerate with: npx supabase gen types typescript --project-id <id> > lib/database.types.ts

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      sources: {
        Row: {
          id: string
          name: string
          tier: 1 | 2 | 3
          domain: string | null
          region_tag: 'VN' | 'GLOBAL'
          enabled: boolean
          notes: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          tier: 1 | 2 | 3
          domain?: string | null
          region_tag: 'VN' | 'GLOBAL'
          enabled?: boolean
          notes?: string | null
          created_at?: string
        }
        Update: Partial<Database['public']['Tables']['sources']['Insert']>
      }

      events_raw: {
        Row: {
          id: string
          source_id: string | null
          fetched_at: string
          url: string
          title_raw: string | null
          body_raw: string | null
          lang: 'EN' | 'VI' | 'OTHER' | null
          content_hash: string | null
        }
        Insert: {
          id?: string
          source_id?: string | null
          fetched_at?: string
          url: string
          title_raw?: string | null
          body_raw?: string | null
          lang?: 'EN' | 'VI' | 'OTHER' | null
          content_hash?: string | null
        }
        Update: Partial<Database['public']['Tables']['events_raw']['Insert']>
      }

      events_clustered: {
        Row: {
          id: string
          created_at: string
          updated_at: string
          cluster_hash: string
          canonical_url: string | null
          canonical_title: string | null
          canonical_summary: string | null
          primary_region: 'VN' | 'GLOBAL'
          category: string | null
          severity: 1 | 2 | 3 | 4 | 5 | null
          relevance_vn_score: number | null  // 0.00–1.00
          confidence_level: 'HIGH' | 'MED' | 'DEV'
          status: 'queued' | 'published' | 'held' | 'superseded'
          source_links_json: Json
          last_seen_at: string | null
        }
        Insert: {
          id?: string
          created_at?: string
          updated_at?: string
          cluster_hash: string
          canonical_url?: string | null
          canonical_title?: string | null
          canonical_summary?: string | null
          primary_region: 'VN' | 'GLOBAL'
          category?: string | null
          severity?: 1 | 2 | 3 | 4 | 5 | null
          relevance_vn_score?: number | null
          confidence_level: 'HIGH' | 'MED' | 'DEV'
          status?: 'queued' | 'published' | 'held' | 'superseded'
          source_links_json?: Json
          last_seen_at?: string | null
        }
        Update: Partial<Database['public']['Tables']['events_clustered']['Insert']>
      }

      versions: {
        Row: {
          id: string
          version_id: string
          created_at: string
          notes: string | null
        }
        Insert: {
          id?: string
          version_id: string
          created_at?: string
          notes?: string | null
        }
        Update: Partial<Database['public']['Tables']['versions']['Insert']>
      }

      fact_cards: {
        Row: {
          id: string
          cluster_id: string | null
          published_at: string
          headline: string
          bullets_json: Json          // string[]
          source_links_json: Json     // { url: string; title?: string }[]
          confidence_level: 'HIGH' | 'MED' | 'DEV'
          lang: 'EN' | 'VI'
          version_id: string
          is_breaking: boolean
        }
        Insert: {
          id?: string
          cluster_id?: string | null
          published_at?: string
          headline: string
          bullets_json?: Json
          source_links_json?: Json
          confidence_level: 'HIGH' | 'MED' | 'DEV'
          lang: 'EN' | 'VI'
          version_id: string
          is_breaking?: boolean
        }
        Update: Partial<Database['public']['Tables']['fact_cards']['Insert']>
      }

      explainers: {
        Row: {
          id: string
          cluster_id: string | null
          published_at: string
          script_text: string
          transcript: string | null
          video_url: string | null
          confidence_score: number | null   // 0.00–1.00
          assumptions_json: Json            // string[]
          what_we_know: string | null
          what_we_dont_know: string | null
          lang: 'EN' | 'VI'
          version_id: string
        }
        Insert: {
          id?: string
          cluster_id?: string | null
          published_at?: string
          script_text: string
          transcript?: string | null
          video_url?: string | null
          confidence_score?: number | null
          assumptions_json?: Json
          what_we_know?: string | null
          what_we_dont_know?: string | null
          lang: 'EN' | 'VI'
          version_id: string
        }
        Update: Partial<Database['public']['Tables']['explainers']['Insert']>
      }

      corrections: {
        Row: {
          id: string
          item_type: 'fact' | 'explainer'
          item_id: string
          created_at: string
          reason: string
          old_version_id: string | null
          new_version_id: string | null
          notes: string | null
        }
        Insert: {
          id?: string
          item_type: 'fact' | 'explainer'
          item_id: string
          created_at?: string
          reason: string
          old_version_id?: string | null
          new_version_id?: string | null
          notes?: string | null
        }
        Update: Partial<Database['public']['Tables']['corrections']['Insert']>
      }

      digests: {
        Row: {
          id: string
          kind: 'daily' | 'weekly'
          lang: 'EN' | 'VI'
          published_at: string
          title: string
          body: string
          items_json: Json    // DigestItem[]
          version_id: string
        }
        Insert: {
          id?: string
          kind: 'daily' | 'weekly'
          lang: 'EN' | 'VI'
          published_at?: string
          title: string
          body: string
          items_json?: Json
          version_id: string
        }
        Update: Partial<Database['public']['Tables']['digests']['Insert']>
      }
    }

    Views: Record<string, never>
    Functions: Record<string, never>
    Enums: {
      confidence_level: 'HIGH' | 'MED' | 'DEV'
      lang: 'EN' | 'VI'
      region: 'VN' | 'GLOBAL'
      cluster_status: 'queued' | 'published' | 'held' | 'superseded'
      item_type: 'fact' | 'explainer'
      digest_kind: 'daily' | 'weekly'
    }
  }
}

// ── Convenience row types ──────────────────────────────────────────────────
export type SourceRow       = Database['public']['Tables']['sources']['Row']
export type EventRawRow     = Database['public']['Tables']['events_raw']['Row']
export type ClusterRow      = Database['public']['Tables']['events_clustered']['Row']
export type VersionRow      = Database['public']['Tables']['versions']['Row']
export type FactCardRow     = Database['public']['Tables']['fact_cards']['Row']
export type ExplainerRow    = Database['public']['Tables']['explainers']['Row']
export type CorrectionRow   = Database['public']['Tables']['corrections']['Row']
export type DigestRow       = Database['public']['Tables']['digests']['Row']
