-- AXIOM NEWS VIETNAM — SUPABASE POSTGRES SCHEMA (v1)

create extension if not exists pgcrypto;

-- 1) SOURCES
create table if not exists sources (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  tier smallint not null check (tier in (1,2,3)),
  domain text,
  region_tag text not null check (region_tag in ('VN','GLOBAL')),
  enabled boolean not null default true,
  notes text,
  created_at timestamptz not null default now()
);

-- 2) RAW EVENTS
create table if not exists events_raw (
  id uuid primary key default gen_random_uuid(),
  source_id uuid references sources(id),
  fetched_at timestamptz not null default now(),
  url text not null,
  title_raw text,
  body_raw text,
  lang text check (lang in ('EN','VI','OTHER')),
  content_hash text
);

create index if not exists idx_events_raw_hash on events_raw(content_hash);
create index if not exists idx_events_raw_fetched_at on events_raw(fetched_at);

-- 3) CLUSTERED EVENTS
create table if not exists events_clustered (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  cluster_hash text not null unique,
  canonical_url text,
  canonical_title text,
  canonical_summary text,
  primary_region text not null check (primary_region in ('VN','GLOBAL')),
  category text,
  severity smallint check (severity between 1 and 5),
  relevance_vn_score numeric(4,2) check (relevance_vn_score between 0 and 1),
  confidence_level text not null check (confidence_level in ('HIGH','MED','DEV')),
  status text not null default 'queued'
      check (status in ('queued','published','held','superseded')),
  source_links_json jsonb not null default '[]'::jsonb,
  last_seen_at timestamptz
);

create index if not exists idx_cluster_status on events_clustered(status);
create index if not exists idx_cluster_updated on events_clustered(updated_at);

-- 4) VERSIONS
create table if not exists versions (
  id uuid primary key default gen_random_uuid(),
  version_id text not null unique,
  created_at timestamptz not null default now(),
  notes text
);

-- 5) FACT CARDS
create table if not exists fact_cards (
  id uuid primary key default gen_random_uuid(),
  cluster_id uuid references events_clustered(id),
  published_at timestamptz not null default now(),
  headline text not null,
  bullets_json jsonb not null default '[]'::jsonb,
  source_links_json jsonb not null default '[]'::jsonb,
  confidence_level text not null
      check (confidence_level in ('HIGH','MED','DEV')),
  lang text not null check (lang in ('EN','VI')),
  version_id text not null,
  is_breaking boolean not null default false
);

create index if not exists idx_fact_cards_published
on fact_cards(published_at desc);

-- 6) EXPLAINERS
create table if not exists explainers (
  id uuid primary key default gen_random_uuid(),
  cluster_id uuid references events_clustered(id),
  published_at timestamptz not null default now(),
  script_text text not null,
  transcript text,
  video_url text,
  confidence_score numeric(4,2)
      check (confidence_score between 0 and 1),
  assumptions_json jsonb not null default '[]'::jsonb,
  what_we_know text,
  what_we_dont_know text,
  lang text not null check (lang in ('EN','VI')),
  version_id text not null
);

create index if not exists idx_explainers_published
on explainers(published_at desc);

-- 7) CORRECTIONS
create table if not exists corrections (
  id uuid primary key default gen_random_uuid(),
  item_type text not null
      check (item_type in ('fact','explainer')),
  item_id uuid not null,
  created_at timestamptz not null default now(),
  reason text not null,
  old_version_id text,
  new_version_id text,
  notes text
);

-- 8) DIGESTS
create table if not exists digests (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('daily','weekly')),
  lang text not null check (lang in ('EN','VI')),
  published_at timestamptz not null default now(),
  title text not null,
  body text not null,
  items_json jsonb not null default '[]'::jsonb,
  version_id text not null
);