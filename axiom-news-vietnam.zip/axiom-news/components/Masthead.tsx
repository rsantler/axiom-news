'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'

const NAV = [
  { href: '/live', label: 'Live Wire' },
  { href: '/explains', label: 'Explainers' },
  { href: '/digest/daily', label: 'Daily Wrap' },
  { href: '/digest/weekly', label: 'Weekly Outlook' },
  { href: '/corrections', label: 'Corrections' },
  { href: '/about', label: 'About' },
]

export default function Masthead() {
  const pathname = usePathname()

  return (
    <header className="masthead">
      <div className="masthead-inner">
        <Link href="/" className="masthead-logo">
          <span className="masthead-logo-name">AXIOM</span>
          <span className="masthead-logo-sub">News Vietnam · AI-Assisted · Facts Only</span>
        </Link>

        <nav className="masthead-nav">
          {NAV.map(n => (
            <Link
              key={n.href}
              href={n.href}
              className={pathname.startsWith(n.href) ? 'active' : ''}
            >
              {n.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  )
}
