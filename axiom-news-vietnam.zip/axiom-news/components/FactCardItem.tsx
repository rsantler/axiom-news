import Link from 'next/link'
import type { FactCard } from '@/types'
import ConfidenceBadge from './ConfidenceBadge'

interface Props {
  card: FactCard
  showFull?: boolean
}

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime()
  const mins = Math.floor(diff / 60000)
  if (mins < 60) return `${mins}m ago`
  const hrs = Math.floor(mins / 60)
  if (hrs < 24) return `${hrs}h ago`
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

export default function FactCardItem({ card, showFull = false }: Props) {
  const bullets: string[] = Array.isArray(card.bullets_json) ? card.bullets_json : []
  const sources: { url: string; title?: string }[] = Array.isArray(card.source_links_json)
    ? card.source_links_json
    : []

  return (
    <article className={`fact-card ${card.is_breaking ? 'fact-card-breaking' : ''}`}>
      <div className="fact-card-header">
        <div className="fact-card-meta">
          {card.is_breaking && card.confidence_level === 'HIGH' && (
            <span className="badge badge-BREAKING">⚡ Breaking</span>
          )}
          <ConfidenceBadge level={card.confidence_level} />
          {card.lang === 'VI' && (
            <span className="badge" style={{ background: '#f0f7ff', color: '#1a3a5c', border: '1px solid #b8d0e8' }}>
              VI
            </span>
          )}
        </div>
        <span className="version-id">{card.version_id}</span>
      </div>

      <h3 className="fact-card-headline">
        {card.cluster_id ? (
          <Link href={`/story/${card.cluster_id}`}>{card.headline}</Link>
        ) : (
          card.headline
        )}
      </h3>

      {bullets.length > 0 && (
        <ul className="fact-card-bullets">
          {bullets.map((b, i) => (
            <li key={i}>{b}</li>
          ))}
        </ul>
      )}

      <div className="fact-card-footer">
        {sources.length > 0 && (
          <div className="source-links">
            {sources.slice(0, 3).map((s, i) => (
              <a
                key={i}
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="source-link"
              >
                {s.title ?? new URL(s.url).hostname.replace('www.', '')}
              </a>
            ))}
          </div>
        )}
        <span className="mono text-muted">{timeAgo(card.published_at)}</span>
      </div>
    </article>
  )
}
