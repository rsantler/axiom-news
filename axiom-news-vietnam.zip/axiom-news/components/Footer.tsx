import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="page-footer">
      <div className="page-footer-inner">
        <div>
          <div className="footer-brand">AXIOM News Vietnam</div>
          <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', marginTop: '0.25rem' }}>
            AI-assisted · Facts only · No political endorsements
          </p>
        </div>
        <div className="footer-links">
          <Link href="/methodology">Methodology</Link>
          <Link href="/corrections">Corrections</Link>
          <Link href="/about">About</Link>
          <Link href="/digest/daily">Daily Wrap</Link>
          <Link href="/digest/weekly">Weekly Outlook</Link>
        </div>
      </div>
    </footer>
  )
}
