import type { ConfidenceLevel } from '@/types'

interface Props {
  level: ConfidenceLevel
  isBreaking?: boolean
}

const LABELS: Record<ConfidenceLevel, string> = {
  HIGH: 'Confirmed',
  MED: 'Developing',
  DEV: 'Unverified',
}

export default function ConfidenceBadge({ level, isBreaking }: Props) {
  return (
    <span className={`badge badge-${level}`}>
      {level === 'DEV' && <span className="badge-dot" />}
      {isBreaking ? (
        <span className="badge badge-BREAKING">⚡ Breaking</span>
      ) : (
        LABELS[level]
      )}
    </span>
  )
}
