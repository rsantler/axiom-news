import Link from 'next/link'
import type { Explainer } from '@/types'

interface Props {
  explainer: Explainer
}

export default function ExplainerCard({ explainer }: Props) {
  const score = explainer.confidence_score ?? 0
  const pct = Math.round(score * 100)

  return (
    <div className="explainer-card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '0.5rem', marginBottom: '0.5rem' }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#8ab4d8' }}>
          Explainer
        </span>
        {explainer.video_url && (
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: '#7ec8a0' }}>▶ Video</span>
        )}
      </div>

      <h3 className="explainer-card-title">
        <Link href={`/story/${explainer.cluster_id}`} style={{ color: 'inherit' }}>
          {explainer.script_text.slice(0, 120)}{explainer.script_text.length > 120 ? '…' : ''}
        </Link>
      </h3>

      {explainer.what_we_know && (
        <p className="explainer-card-summary">{explainer.what_we_know.slice(0, 180)}…</p>
      )}

      <div className="explainer-confidence">
        <div className="confidence-bar">
          <div className="confidence-fill" style={{ width: `${pct}%` }} />
        </div>
        <span className="confidence-label">{pct}% confidence</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'rgba(255,255,255,0.4)' }}>
          {explainer.version_id}
        </span>
      </div>
    </div>
  )
}
