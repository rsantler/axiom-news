import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Methodology — AXIOM News Vietnam',
}

export default function MethodologyPage() {
  return (
    <div className="container-narrow static-page">
      <div className="section-header">
        <span className="section-title">Transparency</span>
        <span className="section-title-accent">Methodology</span>
      </div>

      <h2>How AXIOM Works</h2>
      <p>
        AXIOM News Vietnam is an AI-assisted newsroom focused on fact-first coverage of Vietnam
        and its global context. Every item published goes through a structured verification pipeline
        before appearing on this site.
      </p>

      <h2>Source Tiers</h2>
      <p>
        We classify every source on a three-tier system based on editorial independence, track record,
        and verifiability.
      </p>
      <table>
        <thead>
          <tr>
            <th>Tier</th>
            <th>Description</th>
            <th>Examples</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Tier 1</strong></td>
            <td>Primary source — official statements, government data, wire agencies</td>
            <td>Reuters, AP, VNA, official government portals</td>
          </tr>
          <tr>
            <td><strong>Tier 2</strong></td>
            <td>Established regional media with editorial standards</td>
            <td>VnExpress, Tuổi Trẻ, Nikkei Asia, Bloomberg</td>
          </tr>
          <tr>
            <td><strong>Tier 3</strong></td>
            <td>Contextual or secondary sources; used for corroboration only</td>
            <td>Regional outlets, NGO reports, think tanks</td>
          </tr>
        </tbody>
      </table>

      <h2>Confidence Labels</h2>
      <p>
        Every fact card and explainer carries a confidence label. These reflect the editorial
        certainty of the information at time of publication.
      </p>
      <table>
        <thead>
          <tr>
            <th>Label</th>
            <th>Meaning</th>
            <th>Requirements</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong style={{ color: 'var(--high)' }}>HIGH — Confirmed</strong></td>
            <td>Multiple Tier 1–2 sources corroborate. No significant dispute.</td>
            <td>≥2 independent Tier 1/2 sources</td>
          </tr>
          <tr>
            <td><strong style={{ color: 'var(--med)' }}>MED — Developing</strong></td>
            <td>Corroborated but details are still emerging or evolving.</td>
            <td>At least 1 Tier 1/2 source</td>
          </tr>
          <tr>
            <td><strong style={{ color: 'var(--dev)' }}>DEV — Unverified</strong></td>
            <td>Early reporting. Single source or unconfirmed claims only.</td>
            <td>Published with explicit developing label</td>
          </tr>
        </tbody>
      </table>

      <h2>Breaking News Policy</h2>
      <p>
        A Breaking banner is only shown when a fact card has both <code>is_breaking = true</code> AND{' '}
        <code>confidence_level = HIGH</code>. Unverified alerts are never elevated to Breaking status.
      </p>

      <h2>Explainer Gating</h2>
      <p>
        Explainers are published only when a story has enough confirmed facts to warrant structured
        analysis. We target 6–10 explainers per day. Explainers include explicit "What We Know" and
        "What We Don't Know" sections to avoid false precision.
      </p>

      <h2>Versioning</h2>
      <p>
        Every published item carries a version ID visible in small text. When facts change or errors
        are corrected, a new version is published and the old version is logged in the{' '}
        <a href="/corrections" style={{ color: 'var(--accent)', textDecoration: 'underline' }}>corrections log</a>.
        We do not silently edit published items.
      </p>

      <h2>Scope Exclusions</h2>
      <p>
        AXIOM does not publish political endorsements, moral framing, motive speculation,
        or advocacy content. Our scope is restricted to verifiable factual reporting on
        economic, environmental, diplomatic, and civic events affecting Vietnam.
      </p>

      <h2>Language</h2>
      <p>
        English is the canonical language. Vietnamese translations are provided where available.
        When a Vietnamese translation is not yet ready, English is displayed with a notice.
      </p>
    </div>
  )
}
