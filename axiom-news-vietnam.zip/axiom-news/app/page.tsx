import { createServerClient } from '@/lib/supabase'
import FactCardItem from '@/components/FactCardItem'
import ExplainerCard from '@/components/ExplainerCard'
import ConfidenceBadge from '@/components/ConfidenceBadge'
import Link from 'next/link'
import type { FactCard, Explainer } from '@/types'

export const revalidate = 60 // ISR: revalidate every 60s

async function getData() {
  const supabase = createServerClient()

  const [factsRes, explainersRes, breakingRes] = await Promise.all([
    supabase
      .from('fact_cards')
      .select('*, events_clustered(primary_region, category, status)')
      .eq('lang', 'EN')
      .order('published_at', { ascending: false })
      .limit(30),
    supabase
      .from('explainers')
      .select('*, events_clustered(status)')
      .eq('lang', 'EN')
      .order('published_at', { ascending: false })
      .limit(10),
    supabase
      .from('fact_cards')
      .select('*, events_clustered(primary_region, status)')
      .eq('lang', 'EN')
      .eq('is_breaking', true)
      .eq('confidence_level', 'HIGH')
      .order('published_at', { ascending: false })
      .limit(5),
  ])

  return {
    facts: ((factsRes.data ?? []) as FactCard[]).filter(
      (f: any) => f.events_clustered?.status === 'published'
    ),
    explainers: ((explainersRes.data ?? []) as Explainer[]).filter(
      (e: any) => e.events_clustered?.status === 'published'
    ),
    breaking: ((breakingRes.data ?? []) as FactCard[]).filter(
      (f: any) => f.events_clustered?.status === 'published'
    ),
  }
}

export default async function HomePage() {
  const { facts, explainers, breaking } = await getData()

  const vnFacts = facts.filter((f: any) => f.events_clustered?.primary_region === 'VN')
  const globalFacts = facts.filter((f: any) => f.events_clustered?.primary_region === 'GLOBAL')
  const latestFacts = facts.slice(0, 8)

  return (
    <>
      {/* Breaking Banner */}
      {breaking.length > 0 && (
        <div className="breaking-banner">
          <span className="breaking-label">Breaking</span>
          <div className="breaking-scroll">
            {breaking.map(b => (
              <Link key={b.id} href={`/story/${b.cluster_id}`} style={{ marginRight: '3rem', color: '#fff' }}>
                {b.headline}
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="container" style={{ paddingTop: '0.5rem' }}>

        {/* Breaking section (HIGH confidence only) */}
        {breaking.length > 0 && (
          <section>
            <div className="section-header">
              <span className="section-title">Breaking</span>
              <span className="section-title-accent">Confirmed Reports</span>
            </div>
            <div className="grid-3">
              {breaking.map(card => (
                <FactCardItem key={card.id} card={card} />
              ))}
            </div>
          </section>
        )}

        {/* Latest Explainers */}
        {explainers.length > 0 && (
          <section>
            <div className="section-header">
              <span className="section-title">Analysis</span>
              <span className="section-title-accent">Latest Explainers</span>
              <Link href="/explains" style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--accent)' }}>
                View all →
              </Link>
            </div>
            <div className="grid-3">
              {explainers.slice(0, 3).map(e => (
                <ExplainerCard key={e.id} explainer={e} />
              ))}
            </div>
          </section>
        )}

        {/* Live Wire Feed */}
        <section>
          <div className="section-header">
            <span className="section-title">Live</span>
            <span className="section-title-accent">Wire Feed</span>
            <Link href="/live" style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--accent)' }}>
              Full feed →
            </Link>
          </div>
          <div className="grid-live">
            {latestFacts.length > 0 ? (
              latestFacts.map(card => <FactCardItem key={card.id} card={card} />)
            ) : (
              <div className="empty-state">No facts published yet.</div>
            )}
          </div>
        </section>

        {/* Global → Vietnam Impact */}
        {globalFacts.length > 0 && (
          <section>
            <div className="section-header">
              <span className="section-title">Context</span>
              <span className="section-title-accent">Global → Vietnam Impact</span>
            </div>
            <div className="grid-2">
              {globalFacts.slice(0, 4).map(card => <FactCardItem key={card.id} card={card} />)}
            </div>
          </section>
        )}

        {/* Digest Previews */}
        <div className="grid-2" style={{ marginTop: '2rem', marginBottom: '3rem' }}>
          <div style={{ border: '1px solid var(--border)', padding: '1.5rem', background: '#fff' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.5rem' }}>
              Daily Wrap
            </div>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, marginBottom: '0.75rem' }}>
              End-of-day summary of confirmed facts
            </p>
            <Link href="/digest/daily" style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--accent)', textDecoration: 'underline' }}>
              Read archive →
            </Link>
          </div>
          <div style={{ border: '1px solid var(--border)', padding: '1.5rem', background: '#fff' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.5rem' }}>
              Weekly Outlook
            </div>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: '1.1rem', fontWeight: 600, marginBottom: '0.75rem' }}>
              Stories to watch — trigger conditions, not predictions
            </p>
            <Link href="/digest/weekly" style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--accent)', textDecoration: 'underline' }}>
              Read archive →
            </Link>
          </div>
        </div>

      </div>
    </>
  )
}
