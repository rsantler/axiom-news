import { createServerClient } from '@/lib/supabase'
import type { Explainer } from '@/types'
import Link from 'next/link'

export const revalidate = 120

async function getExplainers() {
  const supabase = createServerClient()
  const { data } = await supabase
    .from('explainers')
    .select('*')
    .eq('lang', 'EN')
    .order('published_at', { ascending: false })
    .limit(30)
  return (data || []) as Explainer[]
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
}

function getYouTubeId(url: string): string | null {
  const m = url.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/)
  return m ? m[1] : null
}

export default async function ExplainsPage() {
  const explainers = await getExplainers()

  return (
    <div className="container" style={{ paddingTop: '1.5rem', paddingBottom: '3rem' }}>
      <div className="section-header">
        <span className="section-title">Analysis</span>
        <span className="section-title-accent">Explainers</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)' }}>
          {explainers.length} explainers
        </span>
      </div>

      {explainers.length === 0 ? (
        <div className="empty-state">No explainers published yet.</div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '2.5rem' }}>
          {explainers.map(e => {
            const pct = Math.round((e.confidence_score ?? 0) * 100)
            const ytId = e.video_url ? getYouTubeId(e.video_url) : null

            return (
              <article key={e.id} style={{ borderBottom: '1px solid var(--border)', paddingBottom: '2rem' }}>
                <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'center', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--accent)' }}>
                    Explainer
                  </span>
                  {e.video_url && (
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--wire-light)', border: '1px solid var(--wire-light)', padding: '0.1rem 0.4rem', borderRadius: '2px' }}>
                      ▶ Video
                    </span>
                  )}
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--muted)', marginLeft: 'auto' }}>
                    {formatDate(e.published_at)}
                  </span>
                </div>

                <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.4rem', fontWeight: 600, lineHeight: 1.25, marginBottom: '0.75rem' }}>
                  <Link href={`/story/${e.cluster_id}`} style={{ color: 'var(--ink)' }}>
                    {e.script_text.slice(0, 200)}{e.script_text.length > 200 ? '…' : ''}
                  </Link>
                </h2>

                {/* Video embed */}
                {ytId && (
                  <div className="video-embed">
                    <iframe
                      src={`https://www.youtube.com/embed/${ytId}`}
                      title="Explainer video"
                      allowFullScreen
                      style={{ border: 'none' }}
                    />
                  </div>
                )}
                {e.video_url && !ytId && (
                  <video controls style={{ width: '100%', maxHeight: '400px', background: '#000', display: 'block' }}>
                    <source src={e.video_url} />
                  </video>
                )}

                {/* What we know / don't know */}
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', margin: '1rem 0' }}>
                  {e.what_we_know && (
                    <div style={{ background: 'var(--high-bg)', border: '1px solid #b8dfc7', padding: '1rem' }}>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--high)', marginBottom: '0.5rem' }}>
                        What We Know
                      </div>
                      <p style={{ fontSize: '0.875rem', lineHeight: 1.6 }}>{e.what_we_know}</p>
                    </div>
                  )}
                  {e.what_we_dont_know && (
                    <div style={{ background: 'var(--dev-bg)', border: '1px solid #f0c878', padding: '1rem' }}>
                      <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--dev)', marginBottom: '0.5rem' }}>
                        What We Don't Know
                      </div>
                      <p style={{ fontSize: '0.875rem', lineHeight: 1.6 }}>{e.what_we_dont_know}</p>
                    </div>
                  )}
                </div>

                {/* Confidence */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: 'var(--muted)' }}>Confidence:</span>
                  <div className="confidence-bar" style={{ width: '120px', background: 'var(--border)' }}>
                    <div className="confidence-fill" style={{ width: `${pct}%`, background: pct > 70 ? 'var(--high)' : pct > 40 ? 'var(--med)' : 'var(--accent)' }} />
                  </div>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem' }}>{pct}%</span>
                  <span className="version-id" style={{ marginLeft: 'auto' }}>{e.version_id}</span>
                </div>
              </article>
            )
          })}
        </div>
      )}
    </div>
  )
}
