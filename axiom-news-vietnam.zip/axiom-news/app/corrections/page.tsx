import { createServerClient } from '@/lib/supabase'
import type { Correction } from '@/types'
import type { Metadata } from 'next'

export const metadata: Metadata = {
  title: 'Corrections — AXIOM News Vietnam',
}

export const revalidate = 300

async function getCorrections() {
  const supabase = createServerClient()
  const { data } = await supabase
    .from('corrections')
    .select('*')
    .order('created_at', { ascending: false })
    .limit(100)
  return (data || []) as Correction[]
}

function formatDateTime(d: string) {
  return new Date(d).toLocaleString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit',
  })
}

export default async function CorrectionsPage() {
  const corrections = await getCorrections()

  return (
    <div className="container-narrow" style={{ paddingTop: '1.5rem', paddingBottom: '3rem' }}>
      <div className="section-header">
        <span className="section-title">Accountability</span>
        <span className="section-title-accent">Corrections</span>
      </div>
      <p style={{ fontSize: '0.9rem', color: 'var(--muted)', marginBottom: '2rem', lineHeight: 1.6 }}>
        We publish all corrections openly. Items are never silently edited. Every correction
        references the old and new version IDs for full traceability.
      </p>

      {corrections.length === 0 ? (
        <div className="empty-state">No corrections on record.</div>
      ) : (
        <div>
          {corrections.map(c => (
            <div key={c.id} className="correction-item">
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', marginBottom: '0.4rem' }}>
                <span style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.65rem',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  background: 'var(--accent)',
                  color: '#fff',
                  padding: '0.15rem 0.4rem',
                }}>
                  Correction
                </span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--muted)', textTransform: 'capitalize' }}>
                  {c.item_type}
                </span>
              </div>
              <p className="correction-reason">{c.reason}</p>
              {c.notes && (
                <p style={{ fontSize: '0.85rem', color: 'var(--muted)', marginBottom: '0.5rem' }}>{c.notes}</p>
              )}
              <div className="correction-meta">
                {c.old_version_id && <span>Previous version: <strong>{c.old_version_id}</strong></span>}
                {c.new_version_id && <span>Current version: <strong>{c.new_version_id}</strong></span>}
                <span>{formatDateTime(c.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
