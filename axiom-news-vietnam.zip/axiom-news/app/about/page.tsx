import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'About — AXIOM News Vietnam',
}

export default function AboutPage() {
  return (
    <div className="container-narrow static-page">
      <div className="section-header">
        <span className="section-title">Who We Are</span>
        <span className="section-title-accent">About AXIOM</span>
      </div>

      <h2>What Is AXIOM?</h2>
      <p>
        AXIOM News Vietnam is a fact-first newsroom covering Vietnam and the global events that
        affect it. We focus exclusively on verifiable, sourced reporting — no opinion, no
        advocacy, no political alignment.
      </p>

      <h2>AI Disclosure</h2>
      <p>
        AXIOM is an AI-assisted newsroom. Artificial intelligence is used to monitor sources,
        cluster related events, draft initial fact cards, and generate explainer scripts.
        All published items pass through a structured validation pipeline before going live.
      </p>
      <p>
        AI-generated content is never published without confidence scoring and source
        verification. The AI does not determine what is true — it structures and presents
        information from verified sources.
      </p>

      <h2>Scope</h2>
      <p>
        We cover economic, environmental, diplomatic, and civic events related to Vietnam.
        We do not cover domestic political endorsements, electoral politics, or content
        that requires moral or subjective framing.
      </p>

      <h2>Non-Endorsement Statement</h2>
      <p>
        AXIOM does not endorse any political party, candidate, government policy, or
        ideological position. Source inclusion does not imply endorsement of that source's
        editorial stance. Confidence labels reflect factual corroboration, not normative judgment.
      </p>

      <h2>Versioning &amp; Corrections</h2>
      <p>
        Every published item carries a version ID. Errors are corrected publicly and logged
        in our <Link href="/corrections" style={{ color: 'var(--accent)', textDecoration: 'underline' }}>corrections log</Link>.
        We do not silently edit published content.
      </p>

      <h2>Methodology</h2>
      <p>
        Our full methodology — source tiers, confidence labels, explainer gating, and scope
        exclusions — is documented on the{' '}
        <Link href="/methodology" style={{ color: 'var(--accent)', textDecoration: 'underline' }}>Methodology page</Link>.
      </p>

      <div style={{ borderTop: '1px solid var(--border)', marginTop: '2rem', paddingTop: '1.5rem' }}>
        <p style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--muted)' }}>
          Questions or corrections? Reach out via the contact details provided to registered partners.
        </p>
      </div>
    </div>
  )
}
