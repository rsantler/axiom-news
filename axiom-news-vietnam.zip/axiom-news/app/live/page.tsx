'use client'

import { useState, useEffect } from 'react'
import FactCardItem from '@/components/FactCardItem'
import type { FactCard, Lang, ConfidenceLevel } from '@/types'

type RegionFilter = 'ALL' | 'VN' | 'GLOBAL'

export default function LivePage() {
  const [facts, setFacts] = useState<FactCard[]>([])
  const [loading, setLoading] = useState(true)
  const [region, setRegion] = useState<RegionFilter>('ALL')
  const [confidence, setConfidence] = useState<ConfidenceLevel | 'ALL'>('ALL')
  const [lang, setLang] = useState<Lang>('EN')

  useEffect(() => {
    setLoading(true)
    const params = new URLSearchParams({ lang, limit: '100' })
    if (confidence !== 'ALL') params.set('confidence', confidence)
    if (region !== 'ALL') params.set('region', region)

    fetch(`/api/facts?${params}`)
      .then(r => r.json())
      .then(d => {
        setFacts(d.data || [])
        setLoading(false)
      })
  }, [lang, region, confidence])

  return (
    <div className="container" style={{ paddingTop: '1.5rem', paddingBottom: '3rem' }}>
      <div className="section-header">
        <span className="section-title">Real-time</span>
        <span className="section-title-accent">Live Wire</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)' }}>
          {facts.length} items
        </span>
      </div>

      <div className="filter-bar">
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)', marginRight: '0.5rem' }}>Region:</span>
        {(['ALL', 'VN', 'GLOBAL'] as RegionFilter[]).map(r => (
          <button key={r} className={`filter-chip ${region === r ? 'active' : ''}`} onClick={() => setRegion(r)}>
            {r}
          </button>
        ))}
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)', marginLeft: '1rem', marginRight: '0.5rem' }}>Confidence:</span>
        {(['ALL', 'HIGH', 'MED', 'DEV'] as const).map(c => (
          <button key={c} className={`filter-chip ${confidence === c ? 'active' : ''}`} onClick={() => setConfidence(c)}>
            {c}
          </button>
        ))}
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)', marginLeft: '1rem', marginRight: '0.5rem' }}>Lang:</span>
        {(['EN', 'VI'] as Lang[]).map(l => (
          <button key={l} className={`filter-chip ${lang === l ? 'active' : ''}`} onClick={() => setLang(l)}>
            {l}
          </button>
        ))}
      </div>

      {loading ? (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {[...Array(6)].map((_, i) => (
            <div key={i} className="skeleton" style={{ height: '120px', borderRadius: '0' }} />
          ))}
        </div>
      ) : facts.length === 0 ? (
        <div className="empty-state">No facts match this filter.</div>
      ) : (
        <div className="grid-live">
          {facts.map(card => <FactCardItem key={card.id} card={card} />)}
        </div>
      )}
    </div>
  )
}
