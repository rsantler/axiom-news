import { createServerClient } from '@/lib/supabase'
import ConfidenceBadge from '@/components/ConfidenceBadge'
import type { FactCard, Explainer, Correction, EventCluster } from '@/types'
import Link from 'next/link'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next'

export const revalidate = 60

interface Props {
  params: { cluster_id: string }
}

async function getData(cluster_id: string, lang = 'EN') {
  const supabase = createServerClient()

  const [clusterRes, factsRes, explainerRes, correctionsRes] = await Promise.all([
    supabase.from('events_clustered').select('*').eq('id', cluster_id).single(),
    supabase
      .from('fact_cards')
      .select('*')
      .eq('cluster_id', cluster_id)
      .eq('lang', lang)
      .order('published_at', { ascending: false }),
    supabase
      .from('explainers')
      .select('*')
      .eq('cluster_id', cluster_id)
      .eq('lang', lang)
      .order('published_at', { ascending: false })
      .limit(1),
    supabase.from('corrections').select('*').order('created_at', { ascending: false }),
  ])

  return {
    cluster: clusterRes.data as EventCluster | null,
    facts: (factsRes.data || []) as FactCard[],
    explainer: explainerRes.data?.[0] as Explainer | undefined,
    corrections: (correctionsRes.data || []) as Correction[],
  }
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const supabase = createServerClient()
  const { data } = await supabase
    .from('events_clustered')
    .select('canonical_title, canonical_summary')
    .eq('id', params.cluster_id)
    .single()

  return {
    title: data?.canonical_title ? `${data.canonical_title} — AXIOM News` : 'Story — AXIOM News Vietnam',
    description: data?.canonical_summary ?? undefined,
  }
}

function formatDateTime(d: string) {
  return new Date(d).toLocaleString('en-US', {
    year: 'numeric', month: 'short', day: 'numeric',
    hour: '2-digit', minute: '2-digit', timeZoneName: 'short',
  })
}

function getYouTubeId(url: string): string | null {
  const m = url.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/)
  return m ? m[1] : null
}

export default async function StoryPage({ params }: Props) {
  const { cluster, facts, explainer, corrections } = await getData(params.cluster_id)

  if (!cluster) notFound()

  const latest = facts[0]
  const history = facts.slice(1)
  const pct = Math.round((explainer?.confidence_score ?? 0) * 100)
  const ytId = explainer?.video_url ? getYouTubeId(explainer.video_url) : null

  // Filter corrections for items in this cluster
  const factIds = facts.map(f => f.id)
  const relatedCorrections = corrections.filter(c => factIds.includes(c.item_id))

  return (
    <div className="container-narrow" style={{ paddingBottom: '3rem' }}>
      {/* Hero */}
      <div className="story-hero">
        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', marginBottom: '0.5rem', flexWrap: 'wrap' }}>
          {cluster.category && (
            <span className="story-category">{cluster.category}</span>
          )}
          <span className="story-category" style={{ color: 'var(--muted)' }}>
            {cluster.primary_region}
          </span>
        </div>

        <h1 className="story-title">{cluster.canonical_title}</h1>

        {cluster.canonical_summary && (
          <p className="story-summary">{cluster.canonical_summary}</p>
        )}

        <div className="story-meta-row">
          <ConfidenceBadge level={cluster.confidence_level} />
          {cluster.severity && (
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)' }}>
              Severity {cluster.severity}/5
            </span>
          )}
          {cluster.relevance_vn_score !== null && cluster.relevance_vn_score !== undefined && (
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', color: 'var(--muted)' }}>
              VN Relevance: {Math.round(cluster.relevance_vn_score * 100)}%
            </span>
          )}
          <span className="version-id" style={{ marginLeft: 'auto' }}>
            Updated {formatDateTime(cluster.updated_at)}
          </span>
        </div>
      </div>

      {/* Corrections Notice */}
      {relatedCorrections.length > 0 && (
        <div style={{ marginBottom: '1.5rem' }}>
          {relatedCorrections.map(c => (
            <div key={c.id} className="correction-item">
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--accent)', marginBottom: '0.4rem' }}>
                Correction
              </div>
              <p className="correction-reason">{c.reason}</p>
              <div className="correction-meta">
                <span>Was: {c.old_version_id}</span>
                <span>Now: {c.new_version_id}</span>
                <span>{formatDateTime(c.created_at)}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Latest Fact */}
      {latest && (
        <section style={{ marginBottom: '2rem' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent)', display: 'inline-block', animation: 'pulse 2s infinite' }} />
            Latest Update
          </div>
          <div className={`fact-card ${latest.is_breaking ? 'fact-card-breaking' : ''}`} style={{ background: '#fff' }}>
            <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '0.5rem', alignItems: 'center', flexWrap: 'wrap' }}>
              <ConfidenceBadge level={latest.confidence_level} isBreaking={latest.is_breaking && latest.confidence_level === 'HIGH'} />
              <span className="version-id">{latest.version_id}</span>
              <span className="version-id" style={{ marginLeft: 'auto' }}>{formatDateTime(latest.published_at)}</span>
            </div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: 600, marginBottom: '0.75rem' }}>
              {latest.headline}
            </h2>
            {Array.isArray(latest.bullets_json) && latest.bullets_json.length > 0 && (
              <ul className="fact-card-bullets">
                {latest.bullets_json.map((b, i) => <li key={i}>{b}</li>)}
              </ul>
            )}
            {Array.isArray(latest.source_links_json) && latest.source_links_json.length > 0 && (
              <div className="source-links" style={{ marginTop: '0.75rem' }}>
                {latest.source_links_json.map((s: any, i: number) => (
                  <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" className="source-link">
                    {s.title ?? new URL(s.url).hostname.replace('www.', '')}
                  </a>
                ))}
              </div>
            )}
          </div>
        </section>
      )}

      {/* Explainer */}
      {explainer && (
        <section style={{ marginBottom: '2rem', background: 'var(--wire)', padding: '1.5rem', position: 'relative' }}>
          <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: '3px', background: 'linear-gradient(90deg, var(--accent), var(--wire-light))' }} />
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: '#8ab4d8', marginBottom: '0.75rem' }}>
            Explainer
          </div>

          {ytId && (
            <div className="video-embed" style={{ marginBottom: '1rem' }}>
              <iframe src={`https://www.youtube.com/embed/${ytId}`} title="Explainer video" allowFullScreen style={{ border: 'none' }} />
            </div>
          )}

          {explainer.what_we_know && (
            <div style={{ marginBottom: '0.75rem' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.1em', color: '#7ec8a0', marginBottom: '0.3rem' }}>
                What We Know
              </div>
              <p style={{ color: '#c5d5e8', fontSize: '0.9rem', lineHeight: 1.6 }}>{explainer.what_we_know}</p>
            </div>
          )}

          {explainer.what_we_dont_know && (
            <div style={{ marginBottom: '1rem' }}>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', textTransform: 'uppercase', letterSpacing: '0.1em', color: '#f0c878', marginBottom: '0.3rem' }}>
                What We Don't Know
              </div>
              <p style={{ color: '#c5d5e8', fontSize: '0.9rem', lineHeight: 1.6 }}>{explainer.what_we_dont_know}</p>
            </div>
          )}

          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <div className="confidence-bar" style={{ width: '100px' }}>
              <div className="confidence-fill" style={{ width: `${pct}%` }} />
            </div>
            <span className="confidence-label">{pct}% confidence</span>
            <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'rgba(255,255,255,0.3)' }}>
              {explainer.version_id}
            </span>
          </div>
        </section>
      )}

      {/* Timeline */}
      {history.length > 0 && (
        <section style={{ marginBottom: '2rem' }}>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '1rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.5rem' }}>
            Version History
          </div>
          <div className="timeline">
            {history.map(card => (
              <div key={card.id} className="timeline-item">
                <div className="timeline-date">{formatDateTime(card.published_at)}</div>
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center', marginBottom: '0.4rem', flexWrap: 'wrap' }}>
                  <ConfidenceBadge level={card.confidence_level} />
                  <span className="version-id">{card.version_id}</span>
                </div>
                <h4 style={{ fontFamily: 'var(--font-display)', fontSize: '1rem', fontWeight: 600, lineHeight: 1.3, marginBottom: '0.5rem' }}>
                  {card.headline}
                </h4>
                {Array.isArray(card.bullets_json) && card.bullets_json.length > 0 && (
                  <ul className="fact-card-bullets">
                    {card.bullets_json.map((b, i) => <li key={i}>{b}</li>)}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Source Links */}
      {Array.isArray(cluster.source_links_json) && cluster.source_links_json.length > 0 && (
        <section>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.5rem' }}>
            Primary Sources
          </div>
          <div className="source-links">
            {(cluster.source_links_json as any[]).map((s, i) => (
              <a key={i} href={s.url} target="_blank" rel="noopener noreferrer" className="source-link">
                ↗ {s.title ?? s.url}
              </a>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
