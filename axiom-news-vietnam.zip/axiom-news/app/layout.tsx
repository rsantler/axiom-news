import type { Metadata } from 'next'
import './globals.css'
import Masthead from '@/components/Masthead'
import Footer from '@/components/Footer'

export const metadata: Metadata = {
  title: 'AXIOM News Vietnam',
  description: 'AI-assisted, fact-first news coverage of Vietnam and its global context.',
  openGraph: {
    siteName: 'AXIOM News Vietnam',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>
        <Masthead />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  )
}
