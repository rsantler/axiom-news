import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase'
import type { Lang } from '@/types'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const lang  = (searchParams.get('lang') ?? 'EN').toUpperCase() as Lang
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '30', 10), 100)

  const supabase = createServerClient()

  const { data, error } = await supabase
    .from('explainers')
    .select(`
      *,
      events_clustered ( status )
    `)
    .eq('lang', lang)
    .order('published_at', { ascending: false })
    .limit(limit)

  if (error) {
    console.error('[/api/explainers]', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Only return explainers whose parent cluster is published
  const results = (data ?? []).filter(
    (e: any) => e.events_clustered?.status === 'published'
  )

  return NextResponse.json(
    { data: results, count: results.length },
    {
      headers: {
        'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120',
      },
    }
  )
}
