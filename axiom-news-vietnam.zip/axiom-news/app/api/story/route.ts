import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase'
import type { Lang } from '@/types'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const id   = searchParams.get('id')
  const lang = (searchParams.get('lang') ?? 'EN').toUpperCase() as Lang

  if (!id) {
    return NextResponse.json({ error: 'Missing id parameter' }, { status: 400 })
  }

  const supabase = createServerClient()

  // Cluster — must be published
  const { data: cluster, error: clusterError } = await supabase
    .from('events_clustered')
    .select('*')
    .eq('id', id)
    .eq('status', 'published')
    .single()

  if (clusterError || !cluster) {
    return NextResponse.json(
      { error: 'Story not found or not yet published' },
      { status: 404 }
    )
  }

  // Fact cards (full timeline, newest first)
  const { data: facts } = await supabase
    .from('fact_cards')
    .select('*')
    .eq('cluster_id', id)
    .eq('lang', lang)
    .order('published_at', { ascending: false })

  // Latest explainer for this cluster
  const { data: explainerRows } = await supabase
    .from('explainers')
    .select('*')
    .eq('cluster_id', id)
    .eq('lang', lang)
    .order('published_at', { ascending: false })
    .limit(1)

  const explainer = explainerRows?.[0] ?? null

  // Corrections for any fact card in this cluster
  const factIds = (facts ?? []).map((f) => f.id)
  let corrections: any[] = []
  if (factIds.length > 0) {
    const { data: corrData } = await supabase
      .from('corrections')
      .select('*')
      .in('item_id', factIds)
      .order('created_at', { ascending: false })
    corrections = corrData ?? []
  }

  return NextResponse.json(
    { cluster, facts: facts ?? [], explainer, corrections },
    {
      headers: {
        'Cache-Control': 'public, s-maxage=30, stale-while-revalidate=60',
      },
    }
  )
}
