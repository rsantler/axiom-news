import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase'
import type { Lang } from '@/types'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const kind  = (searchParams.get('kind') ?? 'daily') as 'daily' | 'weekly'
  const lang  = (searchParams.get('lang') ?? 'EN').toUpperCase() as Lang
  const limit = Math.min(parseInt(searchParams.get('limit') ?? '30', 10), 100)

  if (kind !== 'daily' && kind !== 'weekly') {
    return NextResponse.json(
      { error: "kind must be 'daily' or 'weekly'" },
      { status: 400 }
    )
  }

  const supabase = createServerClient()

  const { data, error } = await supabase
    .from('digests')
    .select('*')
    .eq('kind', kind)
    .eq('lang', lang)
    .order('published_at', { ascending: false })
    .limit(limit)

  if (error) {
    console.error('[/api/digest]', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json(
    { data: data ?? [], count: (data ?? []).length },
    {
      headers: {
        'Cache-Control': 'public, s-maxage=120, stale-while-revalidate=300',
      },
    }
  )
}
