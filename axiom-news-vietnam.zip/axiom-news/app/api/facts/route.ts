import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase'
import type { ConfidenceLevel, Lang, Region } from '@/types'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const lang       = (searchParams.get('lang')       ?? 'EN').toUpperCase() as Lang
  const limit      = Math.min(parseInt(searchParams.get('limit') ?? '50', 10), 200)
  const confidence = searchParams.get('confidence')?.toUpperCase() as ConfidenceLevel | null
  const region     = searchParams.get('region')?.toUpperCase() as Region | null

  const supabase = createServerClient()

  // Join cluster to expose region/category and enforce published status
  let query = supabase
    .from('fact_cards')
    .select(`
      *,
      events_clustered (
        id,
        primary_region,
        category,
        canonical_title,
        status
      )
    `)
    .eq('lang', lang)
    .order('published_at', { ascending: false })
    .limit(limit)

  if (confidence) {
    query = query.eq('confidence_level', confidence)
  }

  const { data, error } = await query

  if (error) {
    console.error('[/api/facts]', error)
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  // Post-filter: only published clusters + optional region
  // (Supabase REST doesn't support WHERE on joined tables directly)
  let results = (data ?? []).filter(
    (f: any) => f.events_clustered?.status === 'published'
  )

  if (region) {
    results = results.filter(
      (f: any) => f.events_clustered?.primary_region === region
    )
  }

  return NextResponse.json(
    { data: results, count: results.length },
    {
      headers: {
        'Cache-Control': 'public, s-maxage=30, stale-while-revalidate=60',
      },
    }
  )
}
