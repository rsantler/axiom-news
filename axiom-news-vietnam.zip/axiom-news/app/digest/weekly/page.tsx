import { createServerClient } from '@/lib/supabase'
import Link from 'next/link'
import type { Digest } from '@/types'

export const revalidate = 600

async function getDigests() {
  const supabase = createServerClient()
  const { data } = await supabase
    .from('digests')
    .select('*')
    .eq('kind', 'weekly')
    .eq('lang', 'EN')
    .order('published_at', { ascending: false })
    .limit(20)
  return (data || []) as Digest[]
}

function formatDate(d: string) {
  return new Date(d).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
}

export default async function WeeklyDigestPage() {
  const digests = await getDigests()

  return (
    <div className="container-narrow" style={{ paddingTop: '1.5rem', paddingBottom: '3rem' }}>
      <div className="section-header">
        <span className="section-title">Archive</span>
        <span className="section-title-accent">Weekly Outlook</span>
      </div>
      <p style={{ fontFamily: 'var(--font-body)', fontSize: '0.9rem', color: 'var(--muted)', marginBottom: '2rem', lineHeight: 1.6 }}>
        Stories to monitor the coming week — trigger conditions only. No predictions, no advocacy.
      </p>

      {digests.length === 0 ? (
        <div className="empty-state">No weekly outlooks published yet.</div>
      ) : (
        <div>
          {digests.map(d => {
            const items: any[] = Array.isArray(d.items_json) ? d.items_json : []
            return (
              <div key={d.id} className="digest-card">
                <div className="digest-date">Week of {formatDate(d.published_at)}</div>
                <h2 className="digest-title">{d.title}</h2>
                <p className="digest-body">{d.body}</p>
                {items.length > 0 && (
                  <div className="digest-items">
                    <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--muted)', marginBottom: '0.5rem' }}>
                      Monitoring List
                    </div>
                    {items.map((item, i) => (
                      <div key={i} className="digest-item">
                        <span className="digest-item-num">{String(i + 1).padStart(2, '0')}.</span>
                        <div>
                          {item.cluster_id ? (
                            <Link href={`/story/${item.cluster_id}`} style={{ fontWeight: 600, color: 'var(--ink)' }}>
                              {item.headline}
                            </Link>
                          ) : (
                            <span style={{ fontWeight: 600 }}>{item.headline}</span>
                          )}
                          {item.trigger && (
                            <p style={{ fontSize: '0.82rem', color: 'var(--muted)', marginTop: '0.2rem', fontStyle: 'italic' }}>
                              Watch for: {item.trigger}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                <div style={{ marginTop: '0.75rem', fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--muted)' }}>
                  {d.version_id}
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
