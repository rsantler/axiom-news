// Re-export raw DB row types for use in components
export type {
  SourceRow,
  EventRawRow,
  ClusterRow,
  VersionRow,
  FactCardRow,
  ExplainerRow,
  CorrectionRow,
  DigestRow,
} from '@/lib/database.types'

// ── Convenience aliases used across pages/components ──────────────────────
import type {
  FactCardRow,
  ExplainerRow,
  ClusterRow,
  CorrectionRow,
  DigestRow,
} from '@/lib/database.types'

export type FactCard     = FactCardRow
export type Explainer    = ExplainerRow
export type EventCluster = ClusterRow
export type Correction   = CorrectionRow
export type Digest       = DigestRow

// ── Shared sub-types ───────────────────────────────────────────────────────
export type ConfidenceLevel = 'HIGH' | 'MED' | 'DEV'
export type Lang            = 'EN' | 'VI'
export type Region          = 'VN' | 'GLOBAL'
export type ClusterStatus   = 'queued' | 'published' | 'held' | 'superseded'

export interface SourceLink {
  url: string
  title?: string
  tier?: 1 | 2 | 3
}

export interface DigestItem {
  headline: string
  summary?: string
  cluster_id?: string
  confidence_level?: ConfidenceLevel
  trigger?: string  // weekly outlook: "watch for" condition
}
